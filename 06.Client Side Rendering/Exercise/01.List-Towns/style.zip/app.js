import { html, render } from '../../../node_modules/lit-html/lit-html.js';

const root = document.getElementById('root');

document.getElementById('btnLoadTowns').addEventListener('click', (e) => {
  e.preventDefault();
  const data = document.getElementById('towns').value.split(', ');

  const template = () =>
    html`<ul>
      ${data.map((x) => html`<li>${x}</li>`)}
    </ul>`;

  render(template(), root);
});
